/*[
===============================================================================
Datei         : arc_call.c
Inhalt        : Arcnet Interrupt Service Aufrufe am PC
-------------------------------------------------------------------------------
Version       : 1.0  
Datum         : 92-11-20
Autor         : E. Pexa  
Aenderungen   : Fuer J. Wimmer DCS Aufrufe entfernt.
-------------------------------------------------------------------------------
Version       : 1.1  
Datum         : 93-06-15
Autor         : E. Pexa  
Aenderungen   : bei #define LONGSIZE gs_size und gs_ready return eine long Wertes

===============================================================================
]*/

#define LONGSIZE

#include <arcint.h>
#include <dos.h>

union REGS ir, or;
struct comb cobu;
int a_errno;

int tsr_service();

short a_open(char *name, u_short mode)
	 {
	cobu.code = I_OPEN;
	cobu.name = (char far *) name;
	cobu.att = mode;

	return tsr_service();
	 }

	 
short a_create(char *name, u_short mode, u_short attr, u_short size)
	 {
	cobu.code   = I_CREATE;
	cobu.name   = (char far *) name;
	cobu.att    = mode + (attr << 8);
	cobu.bufsiz = size;

	return tsr_service();
	 }


short a_close(u_short path)
	 {
	cobu.code = I_CLOSE;
	cobu.pfad = path;				/* Uebergabe in cobu */

	return tsr_service();
	 }


short a_seek(u_short path, u_int offset)
	 {
	cobu.code = I_SEEK;
	cobu.pfad = path;				/* Uebergabe in cobu */
	cobu.buf = (char far *) offset;

	return tsr_service();
	 }



short a_read(u_short path, u_char *buffer, u_short count)
	 {
	cobu.code = I_READ;
	cobu.pfad = path;				/* Uebergabe in cobu */
	cobu.buf = (char far *) buffer;
	cobu.bufsiz = count;

	return tsr_service();
	 }



short a_write(u_short path, u_char *buffer, u_short count)
	 {
	cobu.code = I_WRITE;
	cobu.pfad = path;				/* Uebergabe in cobu */
	cobu.buf = (char far *) buffer;
	cobu.bufsiz = count;

	return tsr_service();
	 }



#ifdef LONGSIZE
long  a_gs_rdy(pfad)
#else
short a_gs_rdy(pfad)
#endif
u_short pfad;
	 {
	int retval;

	cobu.code = I_GETSTAT;
	cobu.pfad = pfad;				/* Uebergabe in cobu	*/
	cobu.att = SS_Ready;			/* Sub - Code 			*/

	retval = tsr_service() ;
#ifdef LONGSIZE
	return ((long)cobu.bufsiz << 16) + ((long)retval & 0xffffl);
#else
	return retval;
#endif
	 }



#ifdef LONGSIZE
long  a_gs_size(pfad)
#else
short a_gs_size(pfad)
#endif
u_short pfad;
	 {
	int retval;

	cobu.code = I_GETSTAT;
	cobu.pfad = pfad;				/* Uebergabe in cobu	*/
	cobu.att = SS_Size;			/* Sub - Code 			*/

	retval = tsr_service() ;

#ifdef LONGSIZE
	return ((long)cobu.bufsiz << 16) + ((long)retval & 0xffffl);
#else
	return retval;
#endif
	 }


	/* get Network-Buffer size */

short a_ss_size(pfad)
u_short pfad;
	 {
	cobu.code = I_GETSTAT;
	cobu.pfad = pfad;				/* Uebergabe in cobu	*/
	cobu.att = SS_DStat;			/* Sub - Code 			*/

	return tsr_service();
	 }

/* get device name */
short a_gs_devn(u_short pfad, u_char *buffer)
	 {
	cobu.code = I_GETSTAT;
	cobu.pfad = pfad;				/* Uebergabe in cobu	*/
    cobu.buf = (char far *) buffer;
	cobu.att = SS_DevNm;			/* Sub - Code 			*/

	return tsr_service();
	 }

	 
/*  Aufruf des LOCAL Services im TSR Programm  
/*
/*    in "comb" stehen alle Uebergabeparameter 
/*
/*		return :  0 kein Fehler
/*               -# Fehler
/*
*/

int tsr_service()
{
u_char far *vptr;

	/*	Test ob Arcnet-Interruptserver installiert ist */

#ifndef IC
	vptr = (u_char far *) (*((u_int far *) 0x380000l));
	if (!vptr || 
		 (*vptr != INTCODE))
		{
		printf("Arcnet Interrupt Server not started");
		return -1;
		}
#endif


	ir.x.ax = SEG(&cobu);
	ir.x.bx = OFF(&cobu);

	int86(0xE0, &ir, &or);		/* in TSR Programm springen	*/
	
	return (cobu.retval);
}

/* eof */
