/*** B&R TEST PROGRAM  - ARCNET COMMUNICATION TO PLC ***/

#include "arc_call.c";

main()
{
	char		*name={"/n0/CP40/x"};	/* /n0 .... network ID
						   /CP40 .. logical ID of PLC
						   /x ..... file name (always "x") */
	unsigned char 	data[256];
	short   	path_nr;
	short	 	error;

	unsigned int 	i = 0;

	path_nr = a_open(name, 3);

	if(path_nr < 1)
	{
		printf("\n\npath not found !!!\n");
		exit();
	}

	printf("path number=%d\n",path_nr);

	error = a_seek(path_nr, 0x83000000);	/* set file pointer to reggister
						   R0000 */
	if(error < 0)
	{
		printf("\n\n!!! SEEK ERROR -  %d  TERMINATE PROGRAM !!!\n",error *= -1);
		exit();
	}

	error = a_read(path_nr, &data, 10);

	if(error < 0)
		printf("\n\n!!! READ ERROR -  %d  DATA NOT VALID !!!\n",error *= -1);

	else
	{
		printf("\n\n\n **** DATA **** \n");
		printf("REGISTER R0=%d\n", data[0]);
	}
	a_close(path_nr);

	printf("!!! THAT's ALL FOLKS !!!");

}